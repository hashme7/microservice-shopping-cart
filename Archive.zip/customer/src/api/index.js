
module.exports = {
    customer: require('./customer'),
    appEvents: require('./app-events')
}
